
public class YellowDaisy extends Daisy {
	public YellowDaisy(){
		super();
	}
}
