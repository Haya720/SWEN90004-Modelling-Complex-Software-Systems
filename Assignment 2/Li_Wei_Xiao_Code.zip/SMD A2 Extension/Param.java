/*
 * Param class is to store the types of scenario in the model
 */
public class Param {
	public final static String RAMP = "ramp-up-ramp-down";
	public final static String LOW = "low solar luminosity";
	public final static String HIGH = "high solar luminosity";
	public final static String OUR = "our solar luminosity";
	public final static String CURRENT = "maintain current luminosity";
}
