/*
 * The daisy in the daisy world
 */
public class Daisy {
	private double albedo; // the albedo
	private int age; // the age of the daisy
	private int startYear;// the year the daisy was painted
	
	//get the albedo of daisy
	public double getAlbedo() {
		return albedo;
	}

	//set albedo of daisy
	public void setAlbedo(double albedo) {
		this.albedo = albedo;
	}

	//get age of daisy
	public int getAge() {
		return age;
	}

	//set age of daisy
	public void setAge(int age) {
		this.age = age;
	}

	//get start year of daisy
	public int getStartYear() {
		return startYear;
	}

	//set start year of daisy
	public void setStartYear(int startYear) {
		this.startYear = startYear;
	}


}



