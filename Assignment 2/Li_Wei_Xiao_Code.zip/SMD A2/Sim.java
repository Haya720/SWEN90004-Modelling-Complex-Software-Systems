/**
 * The daisy world of the simulation 
 */
public class Sim {

	
	public static void main(String args[]){
		double startWhitePercent=Double.parseDouble(args[0]);
		double startBlackPercent=Double.parseDouble(args[1]);

		double albedoOfwhite = Double.parseDouble(args[2]);
		double albedoOfblack = Double.parseDouble(args[3]);
		
		String scenario = Param.CURRENT; ;
		switch(args[4]){
			case "current":
				scenario = Param.CURRENT;
				break;
			case "our":
				scenario = Param.OUR;
				break;
			case "low":
				scenario = Param.LOW;
				break;
			case "high":
				scenario = Param.HIGH;
				break;
			case "ramp":
				scenario = Param.RAMP;
				break;
		}
		double solarLuminosity = Double.parseDouble(args[5]);
		double albedoOfsurface = Double.parseDouble(args[6]);
		
		int years = Integer.parseInt(args[7]);
		
		double percent = startWhitePercent+startBlackPercent;
		
		// if the sum of input percentage is over than 100%, alert .
		if(percent > 100){
			System.out.println("The sum of percentage of daisy is over 100%, "
					+ "plz have the right input");
		}
		else{
			DaisyWorld dw = new DaisyWorld( startWhitePercent, startBlackPercent,
					 albedoOfwhite, albedoOfblack,
					 scenario, solarLuminosity, albedoOfsurface,years);
			dw.run();
		}
	}
}
