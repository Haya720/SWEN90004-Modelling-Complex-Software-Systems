/*
 * White daisies have a high surface albedo and thus reflect light and heat, 
 * thus cooling the area around them.
 */
public class WhiteDaisy extends Daisy {
	public WhiteDaisy(){
		super();
	}
}