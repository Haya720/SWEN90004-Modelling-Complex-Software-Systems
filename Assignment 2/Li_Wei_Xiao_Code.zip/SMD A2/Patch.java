/*
 * The patch stores all the information about a ground, which contains the 
 * daisy, temperature and how to calculate the patches temperature in each year.
 */
public class Patch {
	private Daisy daisy; // the daisy in the patch
	private double temperature; //patch's temperature
	
	//used for receiving the diffusion of temperature from its neighbors
	private double tmp;
	
	//calculate the temperature of current patch
	public void calcTemp(double albedoOfsurface, double solarLuminosity){
		double absorbedLuminosity = 0;
		double localHeating =0;
		//If no painted daisy, the percentage of absorbed energy is calculated 
		//(1 -albedo-of-surface) and then multiplied by the solar-luminosity
	    //to give a scaled absorbed-luminosity.
		if(daisy==null){
			absorbedLuminosity= (1-albedoOfsurface)*solarLuminosity;

		}else{
			double albeodo = daisy.getAlbedo();
			absorbedLuminosity = (1-albeodo)*solarLuminosity;

		}
		//local-heating is calculated as logarithmic function 
		//of solar-luminosity
		if(absorbedLuminosity>0){
			localHeating = 72*Math.log(absorbedLuminosity)+80;
		}
		else{
			localHeating = 80;
		}
		//set the temperature at this patch to be the average
		//of the current temperature and the local-heating effect
		temperature = (temperature +localHeating)/2;
	}
	
	
	//get the daisy painted in this patch
	public Daisy getDaisy() {
		return daisy;
	}

	//paint the daisy in this patch
	public void setDaisy(Daisy daisy) {
		this.daisy = daisy;
	}
	
	//get the patch's temperature
	public double getTemperature() {
		return temperature;
	}
	
	//set patch's temperature
	public void setTemperature(double temperature) {
		this.temperature = temperature;
	}
	
	//when the daisy dies, remove the daisy
	public void removeDaisy(){
		daisy=null;
	}


	//get the temporary temperature in this patch
	public double getTmp() {
		return tmp;
	}

	//set the temporary temperature in this patch
	public void setTmp(double tmp) {
		this.tmp = tmp;
	}
}
