import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Random;
/*
 * Daisyworld is a world filled with two different types of daisies: 
 * black daisies and white daisies. They differ in albedo, 
 * which is how much energy they absorb as heat from sunlight.
 * In the extension version, there will be three different types of daisies
 */
public class DaisyWorld {
	private final static int length = 29;//length of the array
	private Patch[][] daisyworld = new Patch[length][length];
	
	private int maxAge; // the max age of the daisy
	private double globalTemp; //global temperature in the world
	private int numWhite; // number of white daisies
	private int numBlack; // number of black daisies
	
	private int ticks; // current year in the world
	private int numOfYears; // the total amount of years should run
	
	private double albedoOfwhite; // the albedo of white daisy
	private double albedoOfblack; // the albedo of black daisy
	private double albedoOfsurface; // the albedo of surface
	
	private double startBlackPercent; // start percent of black daisy
	private double startWhitePercent; // start percent of white daisy
	
	private String scenario; //the scenario 
	// the amount of incident energy on each patch from sunlight
	private double solarLuminosity; 
	
	//the csv file to store the population global temperature and luminosity
	private File PopulationCSV;
	private File GlobalTempCSV;
	private File LuminosityCSV;
	
	//BufferedWriter to write the result into the csv files
	private BufferedWriter PopulationBW;
	private BufferedWriter TempBW;
	private BufferedWriter LuminosityBW;

	//whether the program stops, default value is false
	private boolean isInterrupted = false;
	
	//the percent of value to share, default value if 0.5.
	private final static double number = 0.5;
	
	/*
	 * The constructor of the daisyworld
	 */
	public DaisyWorld(double startWhitePercent,double startBlackPercent,
			double albedoOfwhite,double albedoOfblack,
			String scenario,double solarLuminosity,double albedoOfsurface,
			int years){
		this.startWhitePercent=startWhitePercent;
		this.startBlackPercent= startBlackPercent;
		this.albedoOfwhite = albedoOfwhite;
		this.albedoOfblack = albedoOfblack;
		this.scenario = scenario;
		this.solarLuminosity =solarLuminosity;
		this.albedoOfsurface = albedoOfsurface;
		this.numOfYears = years;
		init();
	}
	
	//initialize the daisy world
	public void init(){
		maxAge=25;
		globalTemp=0;
		
		//set each patch of the daisyworld as a new patch
		for(int x=0;x<length;x++){
			for(int y=0; y<length;y++){
				daisyworld[x][y]=new Patch();
			}
		}
		
		//check the input scenario, and change the solar luminosity values
		if(scenario.equals(Param.HIGH)){
			solarLuminosity=1.4;
		}else if(scenario.equals(Param.LOW)){
			solarLuminosity=0.6;
		}else if(scenario.equals(Param.OUR)){
			solarLuminosity=1.0;
		}else if(scenario.equals(Param.RAMP)){
			solarLuminosity=0.8;
		}
		
		int empty=countEmptyPatch();// count the number of empty patch	
		//set number of black daisy
		numBlack = (int) Math.round(empty*startBlackPercent/100);
		//set number of white daisy
		numWhite = (int) Math.floor(empty*startWhitePercent/100);
		
		seedRandomly(numBlack,numWhite);
		countDaisy();
		calcPatchTemp();
		calcGlobalTemp();
		ticks=0;
		csvFormat();
		writeCSV();
		
	}
	
	//runtime procedures
	public void run(){
		//do until the current year is larger than the number of max year
		while(!isInterrupted){
			calcPatchTemp();// calculate the temperature of each patch
			diffuse(number);
	
			checksurvivablility();
				
			countDaisy();
			calcGlobalTemp();
			ticks+=1;// increase the year by 1
			
			//if scenario is “ramp-up-ramp-down” will start the solar 
			//luminosity at a low value, then start increasing it to a high value, 
			//and then bring it back down again over the course of a model run.
			//Other values of this chooser will change the albedo values. 
			if(scenario==Param.RAMP){
				if (ticks>200 && ticks<=400){
					solarLuminosity= new BigDecimal(solarLuminosity+0.005).
							setScale(4, BigDecimal.ROUND_HALF_UP).doubleValue();
				}
				else if(ticks>600 && ticks<=850){
					solarLuminosity= new BigDecimal(solarLuminosity-0.0025).
							setScale(4, BigDecimal.ROUND_HALF_UP).doubleValue();
				}
			}else if(scenario.equals(Param.HIGH)){
				solarLuminosity=1.4;
			}else if(scenario.equals(Param.LOW)){
				solarLuminosity=0.6;
			}else if(scenario.equals(Param.OUR)){
				solarLuminosity=1.0;
			}
			
			writeCSV();//output  the result
			if(ticks>numOfYears){//compare the current year and max value
				isInterrupted=true;
			}
		}
		
	}
	
	//count the number of empty patch in the world
	private int countEmptyPatch(){
		int count=0;
		for(int i=0;i<length;i++){
			for(int j=0; j<length;j++){
				if (daisyworld[i][j].getDaisy()==null){
					count++;
				}
			}
		}
		return count;
	}
	
	
	//set the patch as black daisy 
	private void seedBlack(Patch patch,int age){
		BlackDaisy blackdaisy = new BlackDaisy();
		blackdaisy.setAlbedo(albedoOfblack);
		//set daisy's age
		blackdaisy.setAge(age);
		blackdaisy.setStartYear(ticks);
		patch.setDaisy(blackdaisy);
	}
	
	//set the patch as white daisy 
	private void seedWhite(Patch patch,int age){
		WhiteDaisy whitedaisy = new WhiteDaisy();
		whitedaisy.setAlbedo(albedoOfwhite);
		whitedaisy.setAge(age);
		whitedaisy.setStartYear(ticks);
		patch.setDaisy(whitedaisy);
	}
	
	//Randomly seed the daisies based on the number of each type should be 
	//painted, used to initialize the daisy world 
	private void seedRandomly(int startBlack,int startWhite){
		Random r = new Random();
		int x;
		int y;
		//do until all the daisies have been painted
		while(startBlack!=0 || startWhite !=0){
			if(startBlack>0){
				//random pick a patch
				x = r.nextInt(length);
				y = r.nextInt(length);
				//check if this patch is empty
				if(daisyworld[x][y].getDaisy()==null){
					int age = r.nextInt(maxAge);//randomly set the daisy's age
					seedBlack(daisyworld[x][y],age);
					startBlack--;
				}
			}
			
			if(startWhite>0){
				x = r.nextInt(length);
				y = r.nextInt(length);
				if(daisyworld[x][y].getDaisy()==null){
					int age = r.nextInt(maxAge);

					seedWhite(daisyworld[x][y],age);
					startWhite--;
					
				}
			}
		}
	}

	//calculate the temperature of each patch
	private void calcPatchTemp(){
		for(int x=0;x<length;x++){
			for(int y =0 ;y<length;y++){
				daisyworld[x][y].calcTemp(albedoOfsurface, 
								solarLuminosity);
			}
		}
	}
	
	//Tells each patch to give equal shares of (number * 100) percent of the 
	//value of patch-variable to its eight neighboring patches. 
	//number should be between 0 and 1.
	private void diffuse(double diff){
		//set all the temporary temperature as 0
		for(int x=0;x<length;x++){
			for(int y =0 ;y<length;y++){
				daisyworld[x][y].setTmp(0);
			}
		}
		
		for(int x=0;x<length;x++){
			for(int y =0;y<length;y++){
				//temperature of patches in the daisy world
				double currentTemp = daisyworld[x][y].getTemperature();
				
				//Diffusion temperature
				double diffsionTemp = currentTemp*diff;
				//reset the patch's temperature
				daisyworld[x][y].setTemperature(currentTemp-diffsionTemp);
				
				//give equal shares of temperature to its neighboring patches
				for(int a = -1; a<2; a++){
					for(int b =-1; b<2;b++){
						if(!(a==0 && b==0)){
							//check whether the new coordinate is out of bound
							int newX = checkCoord(x+a);
							int newY = checkCoord(y+b);
							//sum 1/8 of temperature gets from each neighbour 
							double tmp = daisyworld[newX][newY].getTmp()+
									diffsionTemp/8;
							
							daisyworld[newX][newY].setTmp(tmp);	
							
						}
					}
				}
			}
		}
		//each patch sum the current temperature and summed tmp temperature
		for(int x=0;x<length;x++){
			for(int y =0 ;y<length;y++){
				Patch patch = daisyworld[x][y];
				double newTemp = patch.getTemperature()+patch.getTmp();

				daisyworld[x][y].setTemperature(newTemp);
			}
		}
	}

	/*
	 * check whether the daisy in a patch is alive and Open ground patches 
	 * that are adjacent to a daisy have a probability of sprouting a daisy 
	 * that is the same color as the neighboring daisy, 
	 * based on a parabolic probability function that depends on the local temperature
	 */
	private void checksurvivablility(){
		for(int x=0;x<length;x++){
			for(int y=0; y<length;y++){
		Random r=new Random();
		ArrayList<Patch> tmp = new ArrayList<Patch>();

		Patch current=daisyworld[x][y];
		
		//avoid new planted daisy to seed another new daisy at the same year
		//the planted year of a daisy must be less than current year
		if(current.getDaisy()!=null && 
				current.getDaisy().getStartYear()<ticks){
			//increase the age of daisy by 1
			int age = current.getDaisy().getAge()+1;
			
			daisyworld[x][y].getDaisy().setAge(age);

			double seedThreshold = 0;
	
			double temp = current.getTemperature();
			
			if(age < maxAge){
				//calculate the seed threshold,
				//growth of new daisies can only occur within 5 degrees C and 40 degrees C
				seedThreshold 
					= 0.1457*temp - 0.0032*(temp*temp) -0.6443;
				float random = r.nextFloat();
				
				//if it is larger than a random value between 0 to 1
				if(seedThreshold > random){
					//get all the empty neighbours;
					for(int a = -1; a<2; a++){
						for(int b =-1; b<2;b++){
							// new coordinate cannot be the same as old one
							if(!(a==0 && b==0)){
								int newX = checkCoord(x+a);
								int newY = checkCoord(y+b);
								
								if(daisyworld[newX][newY].getDaisy()==null){
						
									tmp.add(daisyworld[newX][newY]);
				
								}			
							}
							
						}
					}
	
					 if(tmp.size()>0){
						//randomly pick a neighbour
						int pos = r.nextInt(tmp.size());
						//check the type of daisy in current patch
						if(current.getDaisy().getClass().
								equals(new BlackDaisy().getClass())){
							seedBlack(tmp.get(pos),0);//seed black daisy in this patch
							
						}else if(current.getDaisy().getClass().
								equals(new WhiteDaisy().getClass())){
							seedWhite(tmp.get(pos),0);//seed white daisy in this patch
						}
					 }
					 
				
				}
			}
			else{
				daisyworld[x][y].removeDaisy();
			}
		}}
		}
	}
	//check whether the new coordinate is out of bound, globe the world.
	//if the new coordinate equals to -1 then set the new coordinate to
	// length -1, if equals to length, set as 0;
	private int checkCoord(int x){
		if(x==-1){
			x= length -1;
		}else if(x==length){
			x=0;
		}
		return x;
	}
	
	//calculate the global temperature by sum the temperature in each patch 
	//then divide the number of patches.
	private void calcGlobalTemp(){
		int count = 0;
		double patchTemp = 0;
		for(int x=0;x<length;x++){
			for(int y =0 ;y<length;y++){
				patchTemp += daisyworld[x][y].getTemperature();
				count +=1;
			}
		}
		globalTemp = patchTemp/count;
	}
	//count the number of each daisy in the world
	private void countDaisy(){
		int black = 0;
		int white = 0;
		for(int x=0;x<length;x++){
			for(int y =0 ;y<length;y++){
				if(daisyworld[x][y].getDaisy()!=null){
					//black daisy
					if(daisyworld[x][y].getDaisy().getClass().
							equals(new BlackDaisy().getClass())){
						black +=1;
					}
					//white daisy
					else if(daisyworld[x][y].getDaisy().getClass().
							equals(new WhiteDaisy().getClass())){
						white +=1;
					}
				}
			}
		}
		numBlack = black;
		numWhite = white;
		
	}
	
	/*
	 * define the format of the out put, output the title and predefined 
	 * attributes into the files
	 */
	private void csvFormat(){
		PopulationCSV = new File("Population.csv");
		GlobalTempCSV = new File("Global Temperature.csv");
		LuminosityCSV = new File("Luminosity.csv");

		try {
			PopulationBW = new BufferedWriter(
					new FileWriter(PopulationCSV,false));
			TempBW =new BufferedWriter(
					new FileWriter(GlobalTempCSV,false));
			LuminosityBW = new BufferedWriter(
					new FileWriter(LuminosityCSV,false));
			//title and predefined attributes
			PopulationBW.write("albedo-of-whites"+","+"start-%-whites"+","+
					"start-%-blacks"+","+"albedo-of-blacks"+","+
					"solar-luminosity"+","+"albedo-of-surface"+","+
					"scenario");
			PopulationBW.newLine();
			PopulationBW.write(albedoOfwhite+","+startWhitePercent+","+
					startBlackPercent+","+albedoOfblack+","+solarLuminosity
					+","+albedoOfsurface+","+scenario
			);
			PopulationBW.newLine();
			PopulationBW.newLine();
			PopulationBW.write("\"black\",,,\"white\"");
			PopulationBW.newLine();  
			PopulationBW.write("x,y,,x,y");
			PopulationBW.newLine();
			PopulationBW.close();
			
			//title and predefined attributes
			TempBW.write("albedo-of-whites"+","+"start-%-whites"+","+
					"start-%-blacks"+","+"albedo-of-blacks"+","+
					"solar-luminosity"+","+"albedo-of-surface"+","+
					"scenario");
			TempBW.newLine();
			TempBW.write(albedoOfwhite+","+startWhitePercent+","+
					startBlackPercent+","+albedoOfblack+","+solarLuminosity
					+","+albedoOfsurface+","+scenario
			);
			TempBW.newLine();
			TempBW.newLine();  
			TempBW.write("x,y");
			TempBW.newLine();
			TempBW.close();
			
			//title and predefined attributes
			LuminosityBW.write("albedo-of-whites"+","+"start-%-whites"+","+
					"start-%-blacks"+","+"albedo-of-blacks"+","+
					"solar-luminosity"+","+"albedo-of-surface"+","+
					"scenario");
			LuminosityBW.newLine();
			LuminosityBW.write(albedoOfwhite+","+startWhitePercent+","+
					startBlackPercent+","+albedoOfblack+","+solarLuminosity
					+","+albedoOfsurface+","+scenario
			);
			LuminosityBW.newLine();
			LuminosityBW.newLine();  
			LuminosityBW.write("x,y");
			LuminosityBW.newLine();
			LuminosityBW.close();


		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//write the result into the predefined files
	private void writeCSV(){
		try {
			PopulationBW = new BufferedWriter(
					new FileWriter(PopulationCSV,true));
			TempBW =new BufferedWriter(
					new FileWriter(GlobalTempCSV,true));
			LuminosityBW = new BufferedWriter(
					new FileWriter(LuminosityCSV,true));
//			x is the ticks ,y is the value
//			PopulationBW.write("x,y,,x,y");
			PopulationBW.write(ticks+","+numBlack+","+","+ticks+","+numWhite);
			PopulationBW.newLine();
			PopulationBW.close();
			
//			TempBW.write("x,y");
			TempBW.write(ticks+","+globalTemp);
			TempBW.newLine();
			TempBW.close();

//			LuminosityBW.write("x,y");
			LuminosityBW.write(ticks+","+solarLuminosity);
			LuminosityBW.newLine();
			LuminosityBW.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
