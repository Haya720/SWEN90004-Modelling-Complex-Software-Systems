/*
 * Black daisies have a low surface albedo and thus absorb light and heat, 
 * thus heating the area around them.
 */
public 	class BlackDaisy extends Daisy {
	public BlackDaisy(){
		super();
	}
	
}