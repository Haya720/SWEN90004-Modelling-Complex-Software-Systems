Step 1: Compile all java files, e.g. javac *.java

Version 1: Code without extension
Step 2: run the Sim.java file with 8 arguments,
		1st argument is the start percentage of white daisy, range between 0 to 100.
		2nd argument is the start percentage of black daisy, range between 0 to 100, the sum of first two arguments must be less than 100.
		3rd argument is the albedo of white daisy, range between 0.00 to 1.00
		4th argument is the albedo of black daisy, range between 0.00 to 1.00
		5th argument is the scenario of current test, there are 5 types: current, our, low, high, ramp.
		6th argument is solar luminosity in the world, range between 0.001 to 3.000.
		7th argument is the albedo of surface, range between 0.00 to 1.00
		8th argument is the max year, must be an integer, sugguest to be 1500.

For example: java Sim 20 20 0.75 0.25 current 0.8 0.3 1500

Version 2: Code with extension
Step 2: run the Sim.java file with 10 arguments,
		1st argument is the start percentage of white daisy, range between 0 to 100.
		2nd argument is the start percentage of black daisy, range between 0 to 100.
		3rd argument is the start percentage of yellow daisy, range between 0 to 100. The sum of first three arguments must be less than 100.

		4rd argument is the albedo of white daisy, range between 0.00 to 1.00
		5th argument is the albedo of black daisy, range between 0.00 to 1.00
		6th argument is the albedo of yellow daisy, range between 0.00 to 1.00

		7th argument is the scenario of current test, there are 5 types: current, our, low, high, ramp.
		8th argument is solar luminosity in the world, range between 0.001 to 3.
		9th argument is the albedo of surface, range between 0.00 to 1.00
		10th argument is the max year, must be an integer, sugguest to be 1500.

For example: java Sim 20 20 10 0.75 0.25 0.5 current 0.8 0.3 1500

Step 3: Result
The result will be saved in three different csv files, Population.csv, Global Temperature.csv, and Luminosity.csv.